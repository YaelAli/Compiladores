/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iniciarprocesadoraf;
import java.util.ArrayList;
/**
 *
 * @author princ
 */
public class AFN {
   
    /*Variables*/
    //AFD afd;
    
    
    /*constructores*/
    public AFN() {
        //afd=new AFD();
    }
    /*metodos*/
    
    /*public void iniciar(){
    
    }*/
    public String convertir(String expresion_regular){
    
        String expresion_r=expresion_regular;
        String AFN="";
        int bandera_salida=0;
        
        if(revisarSimbolos(expresion_r)){
            String arbol =creacionArbol(expresion_r);
            //System.out.println("\t"+arbol+"\tprueba");
            if(arbol.charAt(0)=='1'){
                 bandera_salida=1;
            }else{
                AFN=recorrerArbol(arbol);
            }
        }else{
            System.out.println("cadena incorrecta\ningrese una cadena valida");
            bandera_salida=1;
        }
        
        
        if(bandera_salida==1){
            return AFN="no se pudo generar";
        }else{
            
            return AFN;
        }
        
    }
    private String recorrerArbol(String arbol){
        int contador_parentesis= 0, contador_es=0;
        String recorrido="ñ";
        String estados="0";
        String arbol1=arbol;
        String coneccion=" ";
        /*recorrido para crear estados*/
        for(int i=0;i<arbol1.length();i++){
            if(arbol1.charAt(i)=='('){
                contador_parentesis++;
            }else if(arbol1.charAt(i)==')'){
                contador_parentesis--;
            }else if(arbol1.charAt(i)=='ñ'){
                //contador_parentesis--;
            }else if(arbol1.charAt(i)=='.'){
                //contador_es++;
                estados=estados.concat(Integer.toString(contador_es));
                contador_es++;
                estados=estados.concat(Integer.toString(contador_es));
                
            }else{
                contador_es++;
                estados=estados.concat(Integer.toString(contador_es));
                contador_es++;
                estados=estados.concat(Integer.toString(contador_es));
                
            }
        }
        /*recorrido para conectar estados*/
        int posicion=1;
        for(int i=0;i<arbol1.length();i++){
            if(arbol1.charAt(i)=='('){
                contador_parentesis++;
            }else if(arbol1.charAt(i)=='ñ'){
                //contador_parentesis--;
            }else if(arbol1.charAt(i)==')'){
                contador_parentesis--;
            }else if(arbol1.charAt(i)=='.'){
                coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+1)+","+"E\n");
            }else if(arbol1.charAt(i)=='*'){
                if(contador_parentesis==0){
                    if(arbol1.charAt(i-1)==')'){
                        coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+1)+","+"E\n");
                        //coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+1)+","+"E");
                    }
                }else if(contador_parentesis>0){
                    coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+1)+","+"E\n");
                }
                posicion++;
                posicion++;
            }else if(arbol1.charAt(i)=='|'||arbol1.charAt(i)=='+'){
                coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion-2)+","+"E\n");
                coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+2)+","+"E\n");
                coneccion=coneccion.concat(estados.charAt(posicion-2)+"->"+estados.charAt(posicion+1)+","+"E\n");
                coneccion=coneccion.concat(estados.charAt(posicion+2)+"->"+estados.charAt(posicion+1)+","+"E\n");
                posicion++;
                posicion++;
            }else{
                coneccion=coneccion.concat(estados.charAt(posicion)+"->"+estados.charAt(posicion+1)+","+arbol1.charAt(i)+"\n");
                posicion++;
                posicion++;
            }
           
        }
        return coneccion;
    }
    /*lo hice de la manera mas sencilla pero dificil de entender si se me olvida el algoritmo*/
    private String creacionArbol(String expresion_r){
        
        String arbol="ñ";
        int bandera_salida=0;
        
        if(expresion_r.charAt(0)=='*'){
            System.out.println("cadena incorrecta\ningrese una cadena valida");
            bandera_salida=1;
        }else if(expresion_r.charAt(0)=='|'){
            System.out.println("cadena incorrecta\ningrese una cadena valida");
            bandera_salida=1;
        }else if(expresion_r.charAt(0)=='+'){
            System.out.println("cadena incorrecta\ningrese una cadena valida");
            bandera_salida=1;
        }else if(expresion_r.charAt(0)==')'){
            System.out.println("cadena incorrecta\ningrese una cadena valida");
            bandera_salida=1;
        }else{
            if(expresion_r.charAt(0)=='('){
                if(expresion_r.charAt(1)==')'){
                    System.out.println("cadena incorrecta\ningrese una cadena valida");
                    bandera_salida=1;
                }else if(expresion_r.charAt(1)=='*'){
                    System.out.println("cadena incorrecta\ningrese una cadena valida");
                    bandera_salida=1;
                }else if(expresion_r.charAt(1)=='+'){
                    System.out.println("cadena incorrecta\ningrese una cadena valida");
                    bandera_salida=1;
                }else if(expresion_r.charAt(1)=='|'){
                    System.out.println("cadena incorrecta\ningrese una cadena valida");
                    bandera_salida=1;
                }else{
                    for(int i=0;i<expresion_r.length();i++){
                        if(expresion_r.charAt(i)=='('){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='*'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='|'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='+'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)==')'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else{
                            //System.out.println("afuera prueba\ti="+i+"\tarbol="+arbol);
                            if(i+1<expresion_r.length()){
                                //System.out.println("adentro prueba\ti="+i+"\tarbol="+arbol);
                                
                                if(expresion_r.charAt(i+1)=='('){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='*'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='+'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='|'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)==')'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else{
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                    arbol=arbol.concat(Character.toString('.'));
                                }
                            }else{
                                arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                            }
                        }
                    }
                }
            }else{
                for(int i=0;i<expresion_r.length();i++){
                    if(expresion_r.charAt(i)=='('){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='*'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='|'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)=='+'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else if(expresion_r.charAt(i)==')'){
                            arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                        }else{
                            //System.out.println("afuera prueba\ti="+i+"\tarbol="+arbol);
                            if(i+1<expresion_r.length()){
                                //System.out.println("adentro prueba\ti="+i+"\tarbol="+arbol);
                                
                                if(expresion_r.charAt(i+1)=='('){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='*'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='+'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)=='|'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else if(expresion_r.charAt(i+1)==')'){
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                }else{
                                    arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                                    arbol=arbol.concat(Character.toString('.'));
                                }
                            }else{
                                arbol=arbol.concat(Character.toString(expresion_r.charAt(i)));
                            }
                        }
                }
            }
        }
        if(bandera_salida==1){
            return arbol="1";
        }else{
            /*for(int i=0;i<arbol.length();i++){
                arbol. = arbol.charAt(i+1);
            }*/
            return arbol;
        }
    }
    private boolean revisarSimbolos(String cadena){
        
        return true;
    }
    private void cargar_desde(String nombre){
    
    }
    private void guardar_en(String nombre){
    
    }
    private void agregar_transicion(int inicio, int fin, char simbolo){
    
    }
    private void eliminar_transicion(int inicio, int fin, char simbolo){
    
    }
    private int obtener_inicial(){
    
        int inicial=0;
        
        
        return inicial;
    }
    private String obtener_finales(){
    
        String finales="finale";
        
    return finales;
    }
    private void establecer_inicial(int estado){
        
    }
    private void establecer_final(int estado){
        
    }
    private boolean esAFN(){
        
        boolean esAFN=true;
        
        return esAFN;
    }
    private boolean esAFD(){
        
        boolean esAFD=true;
        
        return esAFD;
    }   
    private boolean acepta(String cadena){
        boolean esAFD=true;
        
        return esAFD;
    }
    private String generar_cadena(){
        String finales="finale";
        
    return finales;
    }
    /*toString*/
    
}
