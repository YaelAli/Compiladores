/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iniciarprocesadoraf;
import java.util.Scanner;
/**
 *
 * @author princ
 */
public class CentroDeControl {
    /*Variables*/
    
    AFN afn;
    
    /*constructores*/

    public CentroDeControl() {
    
        afn= new AFN();
    }
   
    public CentroDeControl(AFN afn) {
        this.afn = afn;
    }

    /*metodos*/
    
    public void iniciar(){
    
        int bandera = 0;
        do{
            System.out.println("Bienvenido al programa de prueba de metodos de las clases AFN\n"
                                   + "y los procesa en las diferentes opciones descritas a continacion ");
            System.out.println(/*"1.-Cargar AFN desde archivo\n"
                                + "2.-Guardar AFN en...\n"
                                + "3.-Agregar transicion\n"
                                + "4.-Eliminar transicion\n"
                                + "5.-Obtener inicial\n"
                                + "6.-Obtener finales\n"
                                + "7.-Establecer inicial\n"
                                + "8.-Establecer final\n"
                                + "9.-Es AFN?\n"
                                + "10.-Es AFD?\n"*/
                                 "11.-Convertir exprecion regular a AFN11\n"
                                /*+ "12.-Generar cadena\n"*/
                                + "13.-Salir\n");

              Scanner entradaEscaner = new Scanner (System.in); //Creación de un objeto Scanner

              String entradaTeclado = entradaEscaner.nextLine (); //Invocamos un método sobre un objeto Scanner
              int entradaNumTeclado=0;

              if(isNumeric(entradaTeclado)){
                  
                entradaNumTeclado = Integer.parseInt(entradaTeclado);

                if(entradaNumTeclado==1){

                    System.out.println("elegiste opcion 1\n");
                    
                    //afn.iniciar();
                    
                }else if(entradaNumTeclado==2){

                    System.out.println("elegiste opcion 2\n");

                }else if(entradaNumTeclado==3){

                    System.out.println("elegiste opcion 3\n");

                }else if(entradaNumTeclado==4){

                    System.out.println("elegiste opcion 4\n");

                }else if(entradaNumTeclado==5){

                    System.out.println("elegiste opcion 5\n");

                }else if(entradaNumTeclado==6){

                    System.out.println("elegiste opcion 6\n");

                }else if(entradaNumTeclado==7){

                    System.out.println("elegiste opcion 7\n");

                }else if(entradaNumTeclado==8){

                    System.out.println("elegiste opcion 8\n");

                }else if(entradaNumTeclado==9){

                    System.out.println("elegiste opcion 9\n");

                }else if(entradaNumTeclado==10){

                    System.out.println("elegiste opcion 10\n");

                }else if(entradaNumTeclado==11){

                    System.out.println("elegiste opcion 11\n");
                    System.out.println("ingrese la cadena y presione enter:\n");
                    Scanner entradaEscaner11 = new Scanner (System.in); //Creación de un objeto Scanner
                    String entradaTeclado11 = entradaEscaner11.nextLine ();
                    
                    //afn.convertir(entradaTeclado11);
                    System.out.println("\nAFN:\n"+afn.convertir(entradaTeclado11)+"\n");

                }else if(entradaNumTeclado==12){

                    System.out.println("elegiste opcion 12\n");

                }else if(entradaNumTeclado==13){

                    System.out.println("elegiste opcion 13 Salir\n");

                    bandera=1;
                }else{

                    for(int i=0;i<100;i++){
                        System.out.println();
                    }
                    System.out.println("Ingrese una opcion valida");
                }
            }else{
                  for(int i=0;i<100;i++){
                        System.out.println();
                    }
                    System.out.println("Ingrese una opcion valida");
            }
        }while(bandera==0);
    }
    private boolean isNumeric(String cadena){
	try {
		Integer.parseInt(cadena);
		return true;
	} catch (NumberFormatException nfe){
		return false;
	}
}
    
    /*toString*/
}
