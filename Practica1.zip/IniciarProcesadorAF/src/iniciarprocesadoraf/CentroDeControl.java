/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iniciarprocesadoraf;
import java.util.Scanner;
/**
 *
 * @author princ
 */
public class CentroDeControl {
    /*Variables*/
    
    AFN afn;
    
    /*constructores*/

    public CentroDeControl() {
    }
   
    public CentroDeControl(AFN afn) {
        this.afn = afn;
    }

    /*metodos*/
    
    public void iniciar(){
    
        int bandera = 0;
        do{
            System.out.println("Bienvenido a la Practica '1' es un programa que lee archivos que contienen AF\n"
                                   + "y los procesa en las diferentes opciones descritas a continacion ");
            System.out.println("1.-Cargar AF desde archivo\n"
                                + "2.-Guardar AF en...\n"
                                + "3.-Agregar transicion\n"
                                + "4.-Eliminar transicion\n"
                                + "5.-Obtener inicial\n"
                                + "6.-Obtener finales\n"
                                + "7.-Establecer inicial\n"
                                + "8.-Establecer final\n"
                                + "9.-Es AFN?\n"
                                + "10.-Es AFD?\n"
                                + "11.-Acepta esta cadena?\n"
                                + "12.-Generar cadena\n"
                                /*+ "14.-Reiniciar"*/
                                + "13.-Salir\n");

              Scanner entradaEscaner = new Scanner (System.in); //Creación de un objeto Scanner

              String entradaTeclado = entradaEscaner.nextLine (); //Invocamos un método sobre un objeto Scanner
              int entradaNumTeclado=0;

              if(isNumeric(entradaTeclado)){
                  
                entradaNumTeclado = Integer.parseInt(entradaTeclado);

                if(entradaNumTeclado==1){

                    System.out.println("elegiste opcion 1\n");

                }else if(entradaNumTeclado==2){

                    System.out.println("elegiste opcion 2\n");

                }else if(entradaNumTeclado==3){

                    System.out.println("elegiste opcion 3\n");

                }else if(entradaNumTeclado==4){

                    System.out.println("elegiste opcion 4\n");

                }else if(entradaNumTeclado==5){

                    System.out.println("elegiste opcion 5\n");

                }else if(entradaNumTeclado==6){

                    System.out.println("elegiste opcion 6\n");

                }else if(entradaNumTeclado==7){

                    System.out.println("elegiste opcion 7\n");

                }else if(entradaNumTeclado==8){

                    System.out.println("elegiste opcion 8\n");

                }else if(entradaNumTeclado==9){

                    System.out.println("elegiste opcion 9\n");

                }else if(entradaNumTeclado==10){

                    System.out.println("elegiste opcion 10\n");

                }else if(entradaNumTeclado==11){

                    System.out.println("elegiste opcion 11\n");

                }else if(entradaNumTeclado==12){

                    System.out.println("elegiste opcion 12\n");

                }else if(entradaNumTeclado==13){

                    System.out.println("elegiste opcion 13 Salir\n");

                    bandera=1;
                }else{

                    for(int i=0;i<100;i++){
                        System.out.println();
                    }
                    System.out.println("Ingrese una opcion valida");
                }
            }else{
                  for(int i=0;i<100;i++){
                        System.out.println();
                    }
                    System.out.println("Ingrese una opcion valida");
            }
        }while(bandera==0);
    }
    private boolean isNumeric(String cadena){
	try {
		Integer.parseInt(cadena);
		return true;
	} catch (NumberFormatException nfe){
		return false;
	}
}
    
    /*toString*/
}
