/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iniciarprocesadoraf;

/**
 *
 * @author princ
 */
public class AFD {

    /*Variables*/
    
    
    
    /*constructores*/
    public AFD() {
        
    }
    
    /*metodos*/
    
    private void cargar_desde(String nombre){
    
    }
    private void guardar_en(String nombre){
    
    }
    private void agregar_transicion(int inicio, int fin, char simbolo){
    
    }
    private void eliminar_transicion(int inicio, int fin, char simbolo){
    
    }
    private int obtener_inicial(){
    
        int inicial=0;
        
        
        return inicial;
    }
    private String obtener_finales(){
    
        String finales="finale";
        
    return finales;
    }
    private void establecer_inicial(int estado){
        
    }
    private void establecer_final(int estado){
        
    }
    private boolean esAFN(){
        
        boolean esAFN=true;
        
        return esAFN;
    }
    private boolean esAFD(){
        
        boolean esAFD=true;
        
        return esAFD;
    }   
    private boolean acepta(String cadena){
        boolean esAFD=true;
        
        return esAFD;
    }
    private String generar_cadena(){
        String finales="finale";
        
    return finales;
    }
    /*toString*/
    
}
